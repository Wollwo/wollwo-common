# #: Importing modules
# from .module1 import function1
# from .module2 import function2
#
# #: Defining what is available for import
# __all__ = ['function1', 'function2']