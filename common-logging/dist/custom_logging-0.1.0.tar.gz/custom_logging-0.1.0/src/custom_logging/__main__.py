if __name__ == '__main__':
    print("This is not meant to be run with <python -m package>")